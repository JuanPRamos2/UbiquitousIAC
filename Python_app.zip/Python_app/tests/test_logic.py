import health_api
from books_api import filter_books
from config_store import load, restore_defaults, save


def test_filter_by_isbn_title_year_and_price():
    books = [
        {"isbn": "111", "title": "Dune", "publicationYear": 1965, "price": 20},
        {"isbn": "222", "title": "1984", "publicationYear": 1949, "price": 10},
        {"isbn": "333", "title": "Fundación", "publicationYear": 1951, "price": 30},
    ]
    assert [book["isbn"] for book in filter_books(books, title="dun")] == ["111"]
    assert [book["isbn"] for book in filter_books(books, year="1949")] == ["222"]
    assert [book["isbn"] for book in filter_books(books, price_min="15", price_max="25")] == ["111"]
    assert [book["isbn"] for book in filter_books(books, isbn="33")] == ["333"]


def test_health_three_states():
    assert health_api.classify(0, {}) == "down"
    assert health_api.classify(200, {"database": "ok"}) == "up"
    assert health_api.classify(200, {"postgres": "ok"}) == "up"
    assert health_api.classify(503, {"postgres": "error"}) == "degraded"
    assert health_api.classify(200, {"database": "error"}) == "degraded"
    assert health_api.classify(404, {}) == "degraded"


def test_config_persists_and_restores(monkeypatch, tmp_path):
    monkeypatch.setenv("LIBRERIA_PYTHON_HOME", str(tmp_path))
    monkeypatch.delenv("LIBRERIA_LOGIN_URL", raising=False)
    monkeypatch.delenv("LIBRERIA_BOOKS_URL", raising=False)
    saved = save("http://10.0.0.8:5000/", "http://10.0.0.8:5001/")
    assert saved["loginUrl"] == "http://10.0.0.8:5000"
    assert load()["booksUrl"] == "http://10.0.0.8:5001"
    restored = restore_defaults()
    assert restored["loginUrl"] == "http://localhost:5000"
    assert load()["booksUrl"] == "http://localhost:5001"
