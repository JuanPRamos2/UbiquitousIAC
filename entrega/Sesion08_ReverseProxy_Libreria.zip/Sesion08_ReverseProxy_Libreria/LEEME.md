# Sesión 08 — reverse proxy

## Qué hay en esta carpeta

| Ruta | Qué es |
| --- | --- |
| `infra/nginx/library.conf` | Configuración de Nginx que se usó |
| `infra/nginx/proxy_params.conf` | Cabeceras que Nginx reenvía |
| `infra/nginx/salud.py` | Arma el `GET /health` agregado |
| `docs/sesion08/REFLEXION.md` | Cómo se hizo, ventajas y retos |
| `docs/sesion08/evidencias/` | Registros de la prueba |

## Arranque

Desde la raíz del monorepo:

```bash
./scripts/run-con-proxy.sh
```

Eso levanta los seis servicios en `127.0.0.1`, la segunda instancia de libros en 6001 y Nginx en 8080. Si 5433 no es la base `library_db`, usa Postgres en 5434 y Redis en 6380 para no tocar otro proyecto.

Apps:

```bash
./run-tk.sh
./run-electron.sh
cd apps/desktop-classifier
javac cloudclassifier/*.java cloudclassifier/*/*.java
java cloudclassifier.CloudClassifierApp
```

Comprobar otra vez:

```bash
./scripts/probar-proxy.sh
```

Detener los procesos de Python y Nginx, sin borrar Postgres:

```bash
./scripts/run-con-proxy.sh stop
```

## Capturas que faltan

Los registros ya muestran que las tres apps cruzan el proxy. La sesión gráfica no dejó guardar la imagen de cada ventana. Ábrelas con los comandos de arriba y captura:

1. Python Tk, con el catálogo o la pestaña de configuración donde se vean las URLs `:8080/api/...`.
2. Electron, con las tarjetas del catálogo y el endpoint `http://127.0.0.1:8080/api/books`.
3. Java, con el campo SOAP en `http://127.0.0.1:8080/api/books/soap` y una respuesta del servicio.

Guárdalas en `docs/sesion08/evidencias/` y vuelve a armar el zip con `./scripts/empaquetar-sesion08.sh`.

## Si el profesor pide Nginx instalado en el sistema

```bash
sudo pacman -S nginx
./scripts/run-proxy.sh
```

El script usa el binario del sistema cuando existe. El archivo de configuración no cambia.
