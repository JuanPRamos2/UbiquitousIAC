const { app, BrowserWindow, Menu, shell } = require("electron");
const path = require("path");

const GATEWAY = process.env.GATEWAY_URL || "http://127.0.0.1:8080";
const LIBRARY = process.env.LIBRARY_URL || "http://127.0.0.1:3000/library";
const BOOKS = process.env.BOOKS_URL || GATEWAY + "/api/books";

function createWindow() {
  const win = new BrowserWindow({
    width: 1360,
    height: 900,
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  win.loadFile(path.join(__dirname, "catalog.html"));
  win.once("ready-to-show", () => win.show());

  const menu = Menu.buildFromTemplate([
    {
      label: "Librería",
      submenu: [
        {
          label: "Catálogo XML",
          click: () => win.loadFile(path.join(__dirname, "catalog.html")),
        },
        {
          label: "Abrir librería Node (:3000)",
          click: () => win.loadURL(LIBRARY),
        },
        { type: "separator" },
        { role: "reload" },
        { role: "toggleDevTools" },
        { role: "quit" },
      ],
    },
    {
      label: "Microservicio",
      submenu: [
        { label: "Login a través del proxy", click: () => win.loadURL(GATEWAY + "/api/login/docs") },
        { label: "SOAP a través del proxy", click: () => win.loadURL(BOOKS + "/") },
        { label: "GET /books XML", click: () => win.loadURL(BOOKS + "/books") },
        {
          label: "GET /books-images XML",
          click: () => win.loadURL(BOOKS + "/books-images"),
        },
      ],
    },
  ]);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
app.on("web-contents-created", (_event, contents) => {
  contents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
});
