import health_api
from books_api import filter_books
from config_store import load, restore_defaults, save
from http_api import HttpClient, authorization_value, format_exchange, mask_secrets


def test_filter_by_isbn_title_year_and_price():
    books = [
        {"isbn": "111", "title": "Dune", "publicationYear": 1965, "price": 20},
        {"isbn": "222", "title": "1984", "publicationYear": 1949, "price": 10},
        {"isbn": "333", "title": "Fundación", "publicationYear": 1951, "price": 30},
    ]
    assert [book["isbn"] for book in filter_books(books, title="dun")] == ["111"]
    assert [book["isbn"] for book in filter_books(books, year="1949")] == ["222"]
    assert [book["isbn"] for book in filter_books(books, price_min="15", price_max="25")] == ["111"]
    assert [book["isbn"] for book in filter_books(books, isbn="33")] == ["333"]


def test_health_three_states():
    assert health_api.classify(0, {}) == "down"
    assert health_api.classify(200, {"database": "ok"}) == "up"
    assert health_api.classify(200, {"database": "ok", "redis": "error"}) == "degraded"
    assert health_api.classify(200, {"postgres": "ok"}) == "up"
    assert health_api.classify(503, {"postgres": "error"}) == "degraded"
    assert health_api.classify(200, {"database": "error"}) == "degraded"
    assert health_api.classify(404, {}) == "degraded"


def test_console_log_masks_password_and_shows_bearer():
    masked = mask_secrets({"email": "ana@example.com", "password": "ClaveSegura26"})
    assert masked["password"] == "***"
    assert masked["email"] == "ana@example.com"
    assert authorization_value("", True) is None
    assert authorization_value("abc.def.ghi", False) is None
    assert authorization_value("abc.def.ghi", True) == "Bearer abc.def.ghi"
    text = format_exchange(
        "POST",
        "http://localhost:5000/login?format=json",
        {"Accept": "application/json", "Content-Type": "application/json"},
        {"email": "ana@example.com", "password": "ClaveSegura26"},
        401,
        {"code": "CREDENTIALS_INVALID", "errors": ["Credenciales incorrectas."]},
        "Esta operación es pública: no se envía Authorization.",
    )
    assert text.startswith("evidencia | POST ")
    assert "sin Authorization" in text
    assert "Bearer" not in text
    assert "ClaveSegura26" not in text
    assert "{" not in text
    assert "Credenciales incorrectas." in text
    assert "password=***" in text
    assert "HTTP 401" in text


def test_token_is_stored_for_later_requests(monkeypatch, tmp_path):
    monkeypatch.setenv("LIBRERIA_PYTHON_HOME", str(tmp_path))
    client = HttpClient("http://localhost:5000", "http://localhost:5001")
    client.set_token("aaa.bbb.ccc")
    restored = HttpClient("http://localhost:5000", "http://localhost:5001")
    assert restored.token == "aaa.bbb.ccc"
    assert authorization_value(restored.token, True).startswith("Bearer ")
    restored.clear_token()
    empty = HttpClient("http://localhost:5000", "http://localhost:5001")
    assert empty.token == ""


def test_config_persists_and_restores(monkeypatch, tmp_path):
    monkeypatch.setenv("LIBRERIA_PYTHON_HOME", str(tmp_path))
    monkeypatch.delenv("LIBRERIA_LOGIN_URL", raising=False)
    monkeypatch.delenv("LIBRERIA_BOOKS_URL", raising=False)
    saved = save("http://10.0.0.8:5000/", "http://10.0.0.8:5001/")
    assert saved["loginUrl"] == "http://10.0.0.8:5000"
    assert load()["booksUrl"] == "http://10.0.0.8:5001"
    assert load()["scheme"] == "http"
    https = save(
        "https://10.0.0.8:5000",
        "https://10.0.0.8:5001",
        scheme="https",
        usersUrl="https://10.0.0.8:5002",
    )
    assert https["scheme"] == "https"
    assert load()["usersUrl"] == "https://10.0.0.8:5002"
    restored = restore_defaults()
    assert restored["loginUrl"] == "http://127.0.0.1:8080/api/login"
    assert load()["booksUrl"] == "http://127.0.0.1:8080/api/books"
    assert load()["usersUrl"] == "http://127.0.0.1:8080/api/users"
    assert load()["authorsUrl"] == "http://127.0.0.1:8080/api/autores"
    assert load()["pedidosUrl"] == "http://127.0.0.1:8080/api/pedidos"
    assert load()["pagosUrl"] == "http://127.0.0.1:8080/api/pagos"


def test_direct_ports_are_rewritten_to_the_gateway(monkeypatch, tmp_path):
    monkeypatch.setenv("LIBRERIA_PYTHON_HOME", str(tmp_path))
    for name in (
        "LIBRERIA_LOGIN_URL",
        "LIBRERIA_BOOKS_URL",
        "LIBRERIA_USERS_URL",
        "LIBRERIA_AUTHORS_URL",
        "LIBRERIA_PEDIDOS_URL",
        "LIBRERIA_PAGOS_URL",
    ):
        monkeypatch.delenv(name, raising=False)
    save(
        "http://localhost:5000",
        "http://127.0.0.1:5001/",
        usersUrl="http://localhost:5002",
        authorsUrl="http://127.0.0.1:5003",
        pedidosUrl="http://localhost:5004",
        pagosUrl="http://127.0.0.1:5005",
    )
    loaded = load()
    assert loaded["loginUrl"] == "http://127.0.0.1:8080/api/login"
    assert loaded["booksUrl"] == "http://127.0.0.1:8080/api/books"
    assert loaded["usersUrl"] == "http://127.0.0.1:8080/api/users"
    assert loaded["authorsUrl"] == "http://127.0.0.1:8080/api/autores"
    assert loaded["pedidosUrl"] == "http://127.0.0.1:8080/api/pedidos"
    assert loaded["pagosUrl"] == "http://127.0.0.1:8080/api/pagos"
