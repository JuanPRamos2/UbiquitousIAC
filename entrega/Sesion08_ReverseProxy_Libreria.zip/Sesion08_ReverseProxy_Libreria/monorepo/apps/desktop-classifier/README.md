# Clasificador de escritorio con modo SOAP

El endpoint por defecto es el reverse proxy: `http://127.0.0.1:8080/api/books/soap`.
Nginx quita `/api/books` y entrega `POST /soap` al servicio de libros.

```bash
cd apps/desktop-classifier
javac cloudclassifier/*.java cloudclassifier/*/*.java
java cloudclassifier.CloudClassifierApp
```
