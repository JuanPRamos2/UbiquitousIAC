#!/usr/bin/env python3
"""Agrega el /health de cada instancia.

Nginx reparte y registra. No puede, él solo, preguntar a varias instancias y
armar un JSON con el estado de cada una. Este proceso solo hace esa sonda.
No contiene reglas de la librería.
"""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib import error, request

INSTANCIAS = (
    ("login", ("http://127.0.0.1:5000",)),
    ("books", ("http://127.0.0.1:5001", "http://127.0.0.1:6001")),
    ("users", ("http://127.0.0.1:5002",)),
    ("autores", ("http://127.0.0.1:5003",)),
    ("pedidos", ("http://127.0.0.1:5004",)),
    ("pagos", ("http://127.0.0.1:5005",)),
)


def sondear(url):
    try:
        with request.urlopen(url + "/health", timeout=2) as response:
            codigo = response.status
    except error.HTTPError as exc:
        codigo = exc.code
    except Exception as exc:
        return {"url": url, "http": 0, "status": "down", "detalle": type(exc).__name__}
    estado = "up" if codigo == 200 else "degraded"
    return {"url": url, "http": codigo, "status": estado}


class Salud(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.split("?", 1)[0] != "/health":
            self._json(404, {"error": "No encontrado"})
            return
        servicios = {}
        alguna_caida = False
        alguna_viva = False
        for nombre, urls in INSTANCIAS:
            filas = [sondear(url) for url in urls]
            servicios[nombre] = {"instances": filas}
            vivas = [fila for fila in filas if fila["status"] == "up"]
            if vivas:
                alguna_viva = True
            if len(vivas) != len(filas):
                alguna_caida = True
        if not alguna_viva:
            estado, codigo = "down", 503
        elif alguna_caida:
            estado, codigo = "degraded", 503
        else:
            estado, codigo = "ok", 200
        self._json(
            codigo,
            {
                "status": estado,
                "request_id": self.headers.get("X-Request-ID", ""),
                "services": servicios,
            },
        )

    def _json(self, codigo, payload):
        cuerpo = json.dumps(payload).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def log_message(self, formato, *args):
        return


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 8090), Salud).serve_forever()
