# Brief para la IA — Proxy, Load Balancer y API Gateway sobre Library

Pega este documento completo como primer mensaje. No implementes código. El entregable es investigación, diagramas y una presentación de 8 a 12 diapositivas, en español, anclada al proyecto real que se describe abajo. Si un dato no está en este brief, no lo inventes: márcalo como supuesto y explica por qué haría falta confirmarlo en el repositorio.

## Cómo debes trabajar

Eres el apoyo de un equipo de Integración de Aplicaciones Computacionales (UDEM). El equipo va a defender esta arquitectura en clase. La rúbrica pide que demuestren que entendieron **su** sistema, no un microservicio genérico.

Reglas:

1. Reverse proxy, load balancer y API gateway **no son sinónimos**. En cada diagrama y en cada diapositiva, cada caja tiene una sola responsabilidad. Si una herramienta (Nginx, por ejemplo) puede cubrir más de un rol, dilo, y separa en el dibujo qué rol cumple cada bloque de configuración.
2. Usa los puertos, rutas, clientes y resultados de carga de **este** repositorio. La tabla del enunciado de la tarea está desalineada con el código. Si copias esa tabla, la presentación queda mal.
3. No propongas Kubernetes, service mesh, Istio ni una reescritura de los seis Flask. El sistema hoy es una VM de Google Compute Engine, Docker solo para PostgreSQL y Redis, y un proceso Python por microservicio.
4. No muevas al gateway las reglas de negocio (dueño del pedido, stock, monto exacto del pago, un solo administrador). Esas reglas viven en el servicio y en PostgreSQL.
5. Cada afirmación sobre Library debe poder señalarse a un archivo de la lista de evidencia. Cada afirmación sobre Nginx, HAProxy, Traefik, Kong o Google Cloud Load Balancing debe apoyarse en documentación oficial; no cites blogs sin contrastarlos.
6. Deja placeholders `[NOMBRES Y MATRÍCULAS]` en la portada y en la entrega. No inventes integrantes.
7. Redacta la reflexión en primera persona del plural, corta, y advierte al equipo que debe reescribirla con lo que ellos hayan verificado. La tarea dice explícitamente que no basta con entregar texto generado por IA.
8. No incluyas contraseñas, JWT secrets, cadenas de Redis ni la clave de PostgreSQL. Este brief tampoco las trae a propósito.

## Qué hay que entregar

Presentación de 8 a 12 diapositivas (el texto de cada una, listo para pasar a PowerPoint o PDF), más:

- Diagrama de la arquitectura **actual**.
- Diagrama de la arquitectura **propuesta**, con los seis microservicios y el recorrido de una solicitud.
- Guion de animación (pasos numerados, qué se ilumina en cada paso) para el flujo de autenticación JWT y una compra. El equipo ya tiene un HTML de animación en `docs/animacion/index.html` y la clase usa Ubiquitous para la animación visual. Describe los cuadros; no hace falta generar el sitio Ubiquitous.
- Respuestas directas a las seis preguntas de aplicación al proyecto.
- Diapositiva de reflexión con las cinco preguntas del enunciado.
- Referencias con enlace a la documentación oficial consultada.
- Beneficios, limitaciones y justificación técnica.

Distingue con color o forma tres capas: clientes, infraestructura (proxy, balanceador, gateway, TLS) y microservicios. PostgreSQL y Redis son dependencias de datos, no microservicios de la librería.

## Hechos de arquitectura que no puedes contradecir

### Puertos reales

`services/run-all.sh` y los `config.py` publican esto. El enunciado de la tarea cambia pagos, pedidos, users y autores de sitio. Las pruebas Locust midieron los puertos del repositorio y lo advierten en `locust_tests/locustfile.py`.

| Proceso | Puerto | Qué hace | Protocolo hacia el cliente |
| --- | --- | --- | --- |
| Login | 5000 | Registro, login, captcha, verificación de correo, sesión, JWT y refresh | XML por defecto; JSON con `?format=json`. Swagger en `/docs`, UI en `/ui` |
| Books | 5001 | Catálogo, portadas SVG, SOAP | XML por defecto; JSON con `?format=json`. SOAP en `POST /soap` |
| Users | 5002 | Usuarios, roles y contraseñas. El correo no se modifica | JSON |
| Authors | 5003 | Autores y su vínculo con libros | JSON |
| Pedidos | 5004 | Pedidos, líneas, stock y cancelación | JSON |
| Pagos | 5005 | Pagos. Al registrar uno, el pedido pasa a `pagado` | JSON |
| Monolito Node | 3000 | Librería HTML (EJS) anterior. Sigue en el repo y habla **directo** con PostgreSQL | HTML, no es uno de los seis |
| PostgreSQL (Docker) | 5433 en el host, 5432 en el contenedor | Una sola base `library_db` | No es API |
| Redis (Docker) | 6379 | Sesión, refresh, revocación JWT, caché de catálogo y de autores | No es API |

Todos los Flask escuchan en `0.0.0.0` (`HOST` / `LOGIN_HOST` / `SOAP_HOST`). No hay un único nombre público. Cada cliente arma su propia URL con host y puerto.

### No es una malla de microservicios

Los seis procesos **no se llaman por HTTP**. Lo dice `services/README.md` y lo confirma el código: `services/pagos/db.py` abre con «Actualiza el estado del pedido en PostgreSQL, sin llamar al otro proceso.» Pedidos descuenta `books.stock` con `SELECT … FOR UPDATE` dentro de la misma base. Autores enlazan libros por SQL. El monolito Node también usa esa base.

Consecuencia para el diseño: caerse Pedidos no se propaga por una cadena de llamadas HTTP. El acoplamiento real es la base compartida. Un load balancer no separa ese acoplamiento. Tres instancias de Books solo son coherentes si todas usan PostgreSQL y el mismo Redis. `run-all.sh` exporta `SOAP_DEMO=1` para Books: en ese modo el catálogo de demostración es memoria del proceso. **No propongas tres réplicas de Books mientras `SOAP_DEMO=1`.** La propuesta debe exigir `SOAP_DEMO=0` y la base real.

### Quién autentica qué

Login es el único que emite tokens. `services/shared/libreria_platform/jwt_tokens.py`:

- HS256, `iss=login`, `aud=libreria`.
- Claims: `sub`, `user_id`, `email`, `role`, `role_id`, `jti`, `iat`, `exp`.
- Acceso: 20 minutos (`JWT_MINUTES`). Refresh opaco de 1440 minutos, guardado en Redis como hash (`refresh:<sha256>`), no como JWT.
- También hay cookie de sesión Flask (30 minutos) para la UI de login. Los clientes de API usan `Authorization: Bearer`.
- Logout y refresh revocan el `jti` en `jwt:revoked:<jti>`.
- Si Redis no responde, login no abre sesión (503) y cualquier escritura que deba mirar la revocación responde 503. Las lecturas de catálogo siguen y mandan `X-Cache: BYPASS`.

Cada servicio protegido verifica el Bearer **él mismo** con la misma clave compartida (`require_bearer` en `services/shared/libreria_platform/web.py`, y `services/books/jwt_auth.py`). No hay gateway hoy. El secreto HMAC está en todos los procesos: cualquiera de ellos puede firmar un token. Eso es un límite de seguridad que la propuesta debe decir en voz alta.

Matriz real de acceso:

| Servicio | Sin token | Usuario con JWT | Admin (`role_id == 1` o `role=admin`) |
| --- | --- | --- | --- |
| Login | `POST /register` (con captcha), `POST /login`, verificación de correo, `GET /account`, `GET /health`, `/docs`, `/ui`, `/captcha` | `GET /session`, logout, `POST /session` y `/token/refresh`, `PATCH /profile` | El mismo mecanismo; el rol viaja en el token |
| Books | `GET /books`, `GET /books/{isbn}`, `GET /books-images`, `GET /cloud-concepts`, `GET /covers/…`, `GET /health`, WSDL | — | `POST/PUT/PATCH/DELETE /books`. Si no es admin: 403 |
| Authors | `GET /authors`, `GET /authors/{id}`, `GET /health` | — | Altas, cambios, bajas y vínculo autor–libro |
| Users | `GET /health` | Su usuario y su cambio de contraseña (actual, nueva y confirmación) | `GET /users` y el CRUD de cuentas |
| Pedidos | `GET /health` | Solo sus pedidos. `POST /pedidos` con `lines[{isbn, quantity}]`. `PATCH` solo acepta `status=cancelado` | Puede ver todos y crear un pedido para otra cuenta |
| Pagos | `GET /health` | Lista y registra pagos de sus pedidos. El monto tiene que ser el total y el pedido tiene que estar `pendiente` | `PUT/PATCH/DELETE` de pagos; puede pagar un pedido ajeno |

`GET /health` y `GET /metrics` no piden token en ningún servicio. `/metrics` expone el estado de Redis. No deben quedar públicos detrás del nombre único.

SOAP es otro canal, en el mismo proceso de Books (`POST /soap`). Operaciones: `ObtenerConceptosPendientes`, `RegistrarClasificacion`, `ObtenerProgresoUsuario`, `ObtenerEstadisticasPorModelo`. Solo la de estadísticas exige WS-Security UsernameToken (PBKDF2), no JWT. El cliente Java está en `apps/desktop-classifier`. No le pongas validación JWT a `/soap`.

Defecto que el diseño debe cerrar antes de publicar un solo URL: `GET /login` sin cuerpo rellena el administrador de demostración y abre sesión (`services/login/app.py`). Locust no llama ese GET precisamente por eso. Un reverse proxy no debe dejar esa ruta expuesta tal cual.

CORS está en cada proceso, con lista blanca de `http://localhost:3000` y `http://127.0.0.1:5000` (`libreria_platform/web.py`). No hay rate limiting. No hay TLS en los Flask. El documento del monolito (`apps/web-monolito/docs/ARCHITECTURE.md` y `SECURITY_REVIEW.md`) ya decía que el TLS lo termina el reverse proxy y que Node no debía publicarse en `:3000`. Los microservicios no siguieron esa regla.

### Clientes y qué URL guardan

- `apps/Python_app`: escritorio Tk. No abre la base. Tiene **seis** bases URL (`config_store.py`: 5000 a 5005). Manda el Bearer en users, pedidos, pagos y en las escrituras. El catálogo y los autores se leen sin token. La compra la orquesta el cliente: login, luego `POST /pedidos`, luego `POST /pagos`.
- `apps/Electron_app`: solo el catálogo. Pide `GET /books` en XML al puerto 5001 y guarda el endpoint en LocalStorage. Muestra imagen, título, autores, año, ISBN y precio.
- Navegador: Swagger y UI de login en el 5000. El monolito en el 3000 es otra aplicación, con su propia sesión, no con el JWT de login.
- Locust, desde la máquina del equipo hacia la IP pública de la VM, no hacia localhost.

Una sola dirección pública obliga a cambiar esos clientes. Dilo en la propuesta. Hoy no pueden apuntar a un solo origen sin un mapa de rutas, porque **todos** los servicios exponen `/`, `/health` y `/metrics`. Esas rutas chocan si se montan en el mismo host sin prefijo. El mapa tiene que ser explícito, por ejemplo:

- `/login`, `/register`, `/session`, `/token/`, `/verify`, `/account`, `/captcha`, `/profile`, `/logout`, `/docs`, `/ui`, `/openapi.yaml` → login:5000
- `/books`, `/books-images`, `/cloud-concepts`, `/covers/`, `/soap`, `/wsdl` → books
- `/authors` → authors:5003
- `/users` → users:5002
- `/pedidos` → pedidos:5004
- `/pagos` → pagos:5005
- el `/health` público es el del proxy, no el de un Flask. La sonda de cada proceso queda interna: `/internal/books/health`, etc.
- `/metrics` no se publica.

Books y login responden XML si no llega `?format=json`. El proxy no puede forzar `Content-Type: application/json` ni romper el SOAP.

### Compra real (para la animación)

No hay saga ni llamada entre servicios. El cliente hace cuatro saltos:

1. `POST /login?format=json` al 5000. PostgreSQL comprueba el usuario (bcrypt, correo verificado). Redis guarda `session:<jti>` y `refresh:<hash>`. La respuesta trae `token`, `tokenType=Bearer`, `tokenExpiresAt` y `refreshToken`.
2. `GET /books/{isbn}?format=json` al 5001. Público. Redis puede contestar `books:<isbn>` o `books:list:…` (TTL 30 s, encabezado `X-Cache`). Si no hay caché, lee PostgreSQL.
3. `POST /pedidos` al 5004 con Bearer y `lines`. El servicio verifica firma, expiración, audiencia y `jwt:revoked:<jti>`. En la misma transacción bloquea la fila del libro, comprueba stock y lo descuenta. Si no hay stock: 409.
4. `POST /pagos` al 5005 con Bearer, `order_id`, `amount` y `method` (`efectivo`, `tarjeta` o `transferencia`). Verifica que el pedido sea del usuario, que esté `pendiente` y que el monto sea el total. Inserta en `payments` y pone el pedido en `pagado`. No llama al proceso de pedidos.

Si el JWT ya venció, el cliente usa `POST /token/refresh` en login. El refresh viejo se borra y el `jti` anterior se revoca. Un gateway que solo mire `exp` y no consulte Redis aceptaría un token revocado durante unos minutos. La propuesta tiene que elegir: o el gateway consulta `jwt:revoked:<jti>`, o deja esa comprobación en cada servicio. Lo honesto en este código es **las dos**: el gateway rechaza lo obvio (firma, `exp`, `iss`, `aud`, rutas públicas mal expuestas, tasa) y el servicio sigue con `require_bearer` porque ahí está el dueño del recurso. Quitar la verificación de los Flask dejaría los puertos internos abiertos si alguien entra a la VPC.

### Qué mostraron las pruebas de estrés

Fuente: `locust_tests/RESULTADOS.md` y `locust_tests/REFLEXION.md`. Umbral del equipo: degradado si el p95 pasa de 1000 ms o los errores pasan del 5 %. Locust pausa 1–2 s entre tareas, así que el RPS **no** es la capacidad máxima. No midió CPU ni RAM. El objetivo fue la IP pública de una sola VM (`34.68.98.134` en esa corrida), con los siete puertos abiertos.

Comprobación previa, todos en 200: monolito `:3000/library/health`, login `:5000/health`, books `:5001/health` y `:5001/books`, users `:5002`, autores `:5003/authors`, pedidos `:5004`, pagos `:5005`.

- Smoke (1 usuario, 30 s) y load (5 usuarios, 2 min): todas las rutas dentro del umbral, 0 % de errores. En load, `GET /library/books` del monolito tuvo p95 310 ms; `GET /books?format=json` tuvo p95 440 ms.
- Stress (de 2 a 20 usuarios, 3 min): los seis Flask se cayeron por **fallos de conexión (HTTP 0)**, no por latencia. Errores entre 70 % y 86 % según la ruta. El monolito siguió respondiendo y rozó el umbral (`GET /` p95 1100 ms y 5,41 % de errores; `GET /library/health` p95 1700 ms). `GET /users` llegó a p95 5000 ms y 75 % de errores.
- Spike, soak y breakpoint: los Flask se quedaron en 100 % de errores. No se recuperaron solos. El monolito mantuvo las lecturas bajo 1 s, salvo el login del monolito en el spike (p95 1500 ms).
- En la historia del breakpoint el agregado cruza el umbral con 3 usuarios por el porcentaje de errores, con p95 de 360 ms. Es una rampa corta de una sola instancia, no un máximo de producción.

Úsalo así, sin inflarlo: hoy hay un proceso por servicio, arrancado con `app.run` (servidor de desarrollo), sin réplicas, sin sonda que saque de servicio a un proceso muerto y sin reinicio. Abrir 5000–5005 a Internet fue lo que permitió medirlos, y es justo el problema de seguridad. Un balanceador con health check habría dejado de enviar tráfico a un Books muerto **solo si existiera otra instancia sana**. Con una sola instancia de Pedidos, el balanceador no crea disponibilidad: la compra se detiene en el paso 3 y el cliente ve error de conexión. Pagos, si el proceso sigue vivo y la fila del pedido ya existe, todavía puede marcar ese pedido como pagado, porque no depende del proceso de pedidos. Books y login siguen sirviendo. No hay circuit breaker.

PostgreSQL y Redis siguen siendo un solo punto de fallo. Balancear Books no salva una base caída.

### Despliegue que ya está pensado, y el que no

`apps/web-monolito/docs/GCP_COMMANDS.md`: una VM `e2-medium` (2 vCPU, 4 GB) en `us-central1-a`, imagen CentOS, disco de 30 GB. Nginx delante del monolito, HTTP 80, Node en `127.0.0.1:3000`. El propio documento prohíbe abrir el 3000 a `0.0.0.0/0`. No hay grupo de instancias, ni Cloud Load Balancing, ni API Gateway de Google en este repo. Docker Compose solo levanta Postgres 16 y Redis 7.

La recomendación de GCP tiene que partir de esa VM, no de un clúster nuevo.

## Decisiones que la propuesta debe sostener

Defiende esta forma. Puedes afinar nombres de rutas, no el reparto de responsabilidades.

**Load balancer (borde).** Google Cloud HTTPS Load Balancing delante de la VM. Una dirección pública, certificado TLS, health check HTTP contra el `/health` del proxy (no contra un Flask). Cloud Load Balancing no valida JWT, no aplica CORS de aplicación y no entiende que `POST /pagos` exige un pedido pendiente. Si se añaden más VMs, reparte entre ellas. Cloud Armor puede sumar límite grueso y filtrado en el borde; eso sigue siendo protección de perímetro, no el gateway de la API.

**Reverse proxy (salto de red).** Nginx en la VM, que es lo que el monolito ya documentaba. Termina la conexión del cliente (o la que le entrega el balanceador) y abre otra hacia `127.0.0.1:500x`. Los Flask dejan de escuchar en `0.0.0.0` y pasan a `127.0.0.1`. El firewall de GCP solo publica 443 hacia el balanceador. Se cierran 3000 y 5000–5005. El monolito, si sigue desplegado, entra por el mismo Nginx en otro `location` o se apaga: no puede quedar como segunda puerta a la misma base.

**Reparto entre réplicas (también es balanceo, pero interno y distinto del de Google).** Solo Books justifica tres instancias en esta tarea, porque el enunciado lo pregunta y porque el stress lo tumbó junto con los demás. Nginx `upstream` con `least_conn` (el catálogo es lectura con caché; least connections evita seguir cargando un proceso ya lento) y health check activo al `/health` de cada instancia. `max_fails` y `proxy_next_upstream` para no pegarle a la instancia que ya no acepta conexiones: eso es lo que el stress echó de menos. Round robin es aceptable como alternativa más simple; explícalo y di por qué no es el primero. Las otras cinco piezas se quedan en una instancia en esta fase: duplicarlas sin sacarlas de la misma base no da una disponibilidad distinta, y pedidos/pagos escriben las mismas tablas. Si Pedidos muriera, el upstream de una sola réplica lo marca caído y el gateway responde 503 rápido, en lugar del HTTP 0 que vio Locust. Para que la compra sobreviva harían falta dos procesos de Pedidos detrás del mismo upstream, compartiendo PostgreSQL. Propón eso como extensión, no como si ya estuviera medida.

**API gateway (política de API, no el reenvío).** En este tamaño el gateway es el conjunto de reglas de Nginx que el balanceador no tiene: mapa de rutas de la sección anterior, CORS único (`CORS_ORIGINS` deja de estar copiado en seis `.env`), `limit_req` en `/login` y `/register`, cuerpo máximo, ocultar `/metrics` y el `GET /login` sin credenciales, y encabezados de seguridad. La validación criptográfica del JWT puede vivir en Nginx (`auth_request` hacia un endpoint interno de login) **o** quedarse en los Flask. Recomendación para no mentir con el código actual: el gateway exige Bearer en todo lo que la matriz marca como protegido y rechaza tokens mal formados; la firma, la revocación en Redis y el rol los sigue comprobando cada servicio, que ya lo hace. Centralizar toda la autorización en el gateway duplicaría «este pedido es mío» y «este monto cuadra», y un error ahí abriría pagos. Kong haría el JWT y el rate limit con plugins, a cambio de otro proceso que este repo no tiene. Menciónalo como alternativa, no lo pongas en el diagrama principal. Traefik y HAProxy se comparan y se descartan con una razón de este proyecto, no con una tabla genérica.

Comparación que sí se espera, breve, y sin tratarlas como equivalentes:

- **Nginx:** reverse proxy, TLS, `upstream` (round robin, least conn, ip_hash), health pasivo, `limit_req`, enrutado por ruta. No es un producto de API management. Encaja porque el equipo ya lo usa en el monolito.
- **HAProxy:** balanceo y salud de backends muy sólidos, ACL para enrutar. No es el lugar natural para JWT, CORS y portal de API. Serviría si el problema fuera solo repartir Books.
- **Traefik:** reverse proxy con descubrimiento (Docker labels) y middlewares (rate limit, headers). El repo no tiene los Flask en Compose, así que el descubrimiento no aporta hoy. Útil si más adelante cada servicio fuera un contenedor.
- **Kong:** API gateway. JWT, rate limiting, ACL, plugins, métricas. No sustituye al health check del balanceador de Google ni al `upstream` de las tres Books. Es la pieza que sobra en una VM `e2-medium` que ya corre seis Python, Postgres, Redis y Nginx.
- **Google Cloud Load Balancing:** dirección anycast, TLS administrado, health checks, URL map, afinidad, grupos de instancias. No emite ni verifica el JWT de este login. No sabe de `X-Cache` ni de SOAP. Por eso va en el borde y no reemplaza a Nginx ni a la lógica de los Flask.

## Respuestas que el texto debe poder sostener

Escríbelas con estos hechos, en prosa de diapositiva, no como copia de este brief.

1. **Problema de varios puertos.** Seis orígenes públicos, más el 3000. Cada cliente configura host y puerto. El firewall tiene que abrirlos todos, que es lo que Locust usó. `/health` y `/metrics` quedan en Internet. CORS hay que repetirlo. No hay TLS común. No hay una política de tasa. Un proceso muerto no se sustituye: en stress los Flask llegaron a 70–86 % de HTTP 0 y no volvieron. La base única sigue siendo el acoplamiento de pedidos, pagos, stock y autores.
2. **Una sola dirección.** `https://<dominio>` en el Cloud Load Balancer, Nginx enruta por path como en el mapa de arriba, los procesos escuchan en loopback. Python pasa de seis URL a una base. Electron guarda esa base y sigue pidiendo `/books` en XML. El cliente Java sigue en `/soap` sin JWT. El `/health` de cada servicio no se publica con el mismo path.
3. **Dónde va cada control.** TLS y alta disponibilidad de la entrada: Cloud Load Balancing. Reenvío a loopback y reparto least-conn de Books: Nginx como reverse proxy y upstream. Rutas, CORS, rate limit, ocultar métricas y el `GET /login` abierto: reglas de gateway en ese Nginx. Emisión del JWT, refresh y revocación: solo login, con Redis. Firma, `jti` revocado, rol y dueño del recurso: se quedan en cada Flask. Stock y «el pago cuadra»: pedidos y pagos, dentro de la transacción SQL. No pongas la autorización de negocio en el balanceador.
4. **Tres Books.** Tres procesos, `SOAP_DEMO=0`, misma base y mismo Redis (la caché de 30 s y el `X-Cache` siguen siendo válidos; una escritura de admin borra las claves y las tres instancias ven el fallo de caché). Least connections, sonda a `/health`, el cliente no elige instancia. Sin sticky sessions: el catálogo es JWT o anónimo, no hay sesión de Books. El modo demo en memoria haría que cada instancia tuviera un catálogo distinto; por eso se apaga.
5. **Si Pedidos se cae.** Con una instancia, `POST /pedidos` no tiene a quién ir: 503 en el proxy en vez de HTTP 0. Login, catálogo, autores, users y un pago de un pedido que ya exista siguen, porque pagos escribe `orders` por SQL. No se crean pedidos nuevos ni se cancela, y el stock deja de moverse. No hay reintento entre servicios porque nunca se llamaron. Hace falta una segunda instancia de Pedidos, la misma base, y la sonda, si se quiere que la compra continúe. El balanceador no reconstruye un pedido a medias: el cliente es quien encadena los pasos.
6. **GCP.** Cloud HTTPS Load Balancing + Nginx en la VM actual, procesos en loopback, Postgres y Redis como ahora (Redis sigue siendo obligatorio para revocar JWT). Por qué no otra cosa: el curso ya desplegó esta VM; el monolito ya eligió Nginx y ya advirtió que no hay que publicar el puerto de aplicación; Kong o GKE añaden componentes que el stress no pidió. El stress pidió más de un proceso y una sonda. Limitación que debes decir: una sola VM sigue siendo un solo punto de fallo del proxy y de la base; el balanceador de Google solo reparte de verdad cuando hay más de un backend sano. Cloud SQL y Memorystore quedan como paso posterior, no como requisito de esta entrega.

## Estructura de las diapositivas

1. Portada, objetivo, nombres y matrículas en blanco, y una frase: la arquitectura se leyó del repositorio, no de la tabla del enunciado. Incluye la tabla de puertos reales en nota al pie o en el anexo.
2. Proxy y reverse proxy. Qué problema resuelve cada uno. Ejemplo Nginx mínimo en prosa (un `location` que reenvía a `127.0.0.1:5001`), sin venderlo como balanceador ni como gateway.
3. Load balancer: round robin, least connections, health checks, qué pasa con una instancia mala. Ata el stress (HTTP 0, sin recuperación) como el síntoma de no tener esto.
4. API gateway: entrada única, rutas, JWT, CORS, rate limit, métricas. Di qué de eso **ya** está dentro de cada Flask y qué no está en ningún lado.
5. Comparación de Nginx, HAProxy, Traefik, Kong y Google Cloud Load Balancing. Una tabla corta: qué rol cubre y cuál se elige aquí.
6. Diagrama actual: clientes (Tk con seis URL, Electron al 5001, Java a `/soap`, navegador al 5000 y al 3000, Locust a la IP) → seis puertos públicos en `0.0.0.0` → una PostgreSQL y un Redis. Sin caja de gateway.
7. Problemas, con cifras del stress, no con adjetivos.
8. Diagrama propuesto: clientes → Cloud Load Balancing → Nginx (marca qué parte es reverse proxy, qué parte es upstream de Books y qué parte es política de gateway) → seis servicios en loopback, Books ×3 → PostgreSQL y Redis compartidos. Dibuja el monolito aparte, como sistema que todavía no pasa por ahí, o detrás del mismo Nginx si la propuesta lo incluye.
9. Animación, cuadro por cuadro: login (PostgreSQL + Redis + JWT), lectura de libro (caché), alta de pedido (stock), pago (estado `pagado`). En cada cuadro se ve el cliente, el balanceador, el proxy, el gateway, un solo microservicio iluminado y la base. SOAP no entra en esta compra.
10. Caída de Pedidos y las tres Books. Dos recorridos distintos, para que no parezcan el mismo mecanismo.
11. Beneficios, límites (base única, secreto HMAC en todos los procesos, una sola VM, gateway que no sustituye `require_bearer`) y justificación.
12. Reflexión del equipo (cinco preguntas del enunciado) y referencias.

La reflexión debe responder, con este sistema:

- Reverse proxy reenvía y oculta el puerto. Load balancer elige instancia sana. API gateway aplica reglas de la API. Nginx puede hacer trozos de los tres; Google Cloud Load Balancing no hace el trabajo del gateway.
- Lo más necesario **ahora** en Library es dejar de publicar los seis puertos: un reverse proxy con una sola entrada TLS. El balanceo de tres Books es el segundo paso, porque el stress ya tumbó el proceso único. El gateway completo (JWT central, portal, Kong) es el que menos falta: la verificación ya está en cada servicio y moverla entera no arregla el HTTP 0.
- Seguridad: loopback, TLS, sin `/metrics` público, sin `GET /login` vacío. Disponibilidad: sonda y, donde haya dos procesos, dejar fuera al muerto. Escalabilidad: Books en horizontal solo con base y Redis compartidos y sin modo demo.
- Herramientas de IA: nombra las que el equipo haya usado de verdad. La verificación es esta: los puertos salen de `run-all.sh`, el JWT de `jwt_tokens.py`, el pago sin HTTP entre servicios de `pagos/db.py`, las cifras de `locust_tests/RESULTADOS.md`. Lo que no se haya abierto en el repo no se afirma.
- Qué se llevan a otros proyectos: no exponer el puerto del proceso, no compartir el secreto de firma con quien solo necesitaba verificarlo si pueden evitarlo, no llamar «microservicio independiente» a un proceso que actualiza la tabla de otro, y no leer un p95 de Locust con espera de 1–2 s como si fuera la capacidad del servidor.

## Evidencia en el repositorio

Si necesitas citar, estos son los archivos. No hace falta abrir el resto para esta entrega.

- `README.md`, `services/README.md`, `services/run-all.sh`
- `services/shared/libreria_platform/jwt_tokens.py`, `web.py`
- `services/login/app.py`, `services/login/openapi.yaml`
- `services/books/app.py`, `services/books/books_api.py`, `services/books/jwt_auth.py`, `services/books/soap/service.py`
- `services/users/app.py`, `services/authors/app.py`, `services/pedidos/app.py`, `services/pedidos/db.py`
- `services/pagos/app.py`, `services/pagos/db.py`
- `apps/Python_app/config_store.py`, `apps/Python_app/remote_api.py`, `apps/Electron_app/renderer.js`
- `apps/web-monolito/docker-compose.yml`, `apps/web-monolito/docs/ARCHITECTURE.md`, `apps/web-monolito/docs/GCP_COMMANDS.md`, `apps/web-monolito/docs/SECURITY_REVIEW.md`
- `locust_tests/locustfile.py`, `locust_tests/RESULTADOS.md`, `locust_tests/REFLEXION.md`

## Fuentes que debes abrir y citar

- Nginx, `ngx_http_upstream_module` y `ngx_http_limit_req_module`: https://nginx.org/en/docs/
- HAProxy, configuración de backend y checks: https://docs.haproxy.org/
- Traefik, routing y middlewares: https://doc.traefik.io/traefik/
- Kong, JWT y rate limiting: https://docs.konghq.com/
- Google Cloud Load Balancing (external Application Load Balancer) y health checks: https://cloud.google.com/load-balancing/docs
- RFC 7519 (JWT), solo para `iss`, `aud`, `exp` y firma. El detalle de revocación de este proyecto es Redis, no el RFC.

No cites la tabla de puertos del enunciado com si fuera el sistema. Si hace falta mencionarla, di que el código la corrige.

