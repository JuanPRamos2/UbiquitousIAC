#!/usr/bin/env bash
# Arma el zip de la sesión 08: monorepo, Nginx, evidencias y reflexión.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NOMBRE="Sesion08_ReverseProxy_Libreria"
DESTINO="$ROOT/entrega"
STAGE="$(mktemp -d)"
PAQUETE="$STAGE/$NOMBRE"

mkdir -p "$PAQUETE/nginx" "$PAQUETE/evidencias" "$PAQUETE/monorepo" "$DESTINO"
if [ -f /tmp/libreria-nginx/access.log ]; then
  cp /tmp/libreria-nginx/access.log "$ROOT/docs/sesion08/evidencias/nginx-access.log"
fi
if [ -f /tmp/libreria-nginx/error.log ]; then
  cp /tmp/libreria-nginx/error.log "$ROOT/docs/sesion08/evidencias/nginx-error.log"
fi

cp "$ROOT/docs/sesion08/LEEME.md" "$PAQUETE/LEEME.md"
cp "$ROOT/docs/sesion08/REFLEXION.md" "$PAQUETE/REFLEXION.md"
cp "$ROOT/infra/nginx/library.conf" "$ROOT/infra/nginx/proxy_params.conf" "$PAQUETE/nginx/"
cp -a "$ROOT/docs/sesion08/evidencias/." "$PAQUETE/evidencias/"

tar -C "$ROOT" \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='.venv' \
  --exclude='__pycache__' \
  --exclude='.pytest_cache' \
  --exclude='.env' \
  --exclude='services/.run' \
  --exclude='infra/nginx/run' \
  --exclude='entrega' \
  --exclude='*.pyc' \
  --exclude='*.class' \
  --exclude='*.zip' \
  --exclude='*.tar.gz' \
  -cf - . | tar -C "$PAQUETE/monorepo" -xf -

rm -f "$DESTINO/$NOMBRE.zip"
(
  cd "$STAGE"
  zip -qr "$DESTINO/$NOMBRE.zip" "$NOMBRE"
)
rm -rf "$STAGE"
ls -lh "$DESTINO/$NOMBRE.zip"
echo "Listo: $DESTINO/$NOMBRE.zip"
