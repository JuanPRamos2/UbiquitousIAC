#!/usr/bin/env python3
"""Prueba el reverse proxy y guarda el registro en docs/sesion08/evidencias.

No imprime contraseñas, JWT ni el cuerpo completo de login.
"""
import json
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "sesion08" / "evidencias"
OUT.mkdir(parents=True, exist_ok=True)
GATEWAY = "http://127.0.0.1:8080"
LINEAS = []


def anotar(texto):
    print(texto)
    LINEAS.append(texto)


def pedir(metodo, url, cuerpo=None, cabeceras=None, timeout=8):
    data = None
    hdrs = {"Accept": "application/json, application/xml, */*"}
    if cuerpo is not None:
        data = json.dumps(cuerpo).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    if cabeceras:
        hdrs.update(cabeceras)
    req = urllib.request.Request(url, data=data, headers=hdrs, method=metodo)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            return resp.status, dict(resp.headers), raw
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()
    except Exception as exc:
        return 0, {}, str(exc).encode()


def resumir(titulo, status, headers, raw, limite=180):
    rid = headers.get("X-Request-ID") or headers.get("X-Request-Id") or ""
    upstream = headers.get("X-Upstream-Addr") or headers.get("X-Upstream-Addr".lower()) or ""
    # urllib title-cases header names.
    for clave, valor in headers.items():
        if clave.lower() == "x-request-id":
            rid = valor
        if clave.lower() == "x-upstream-addr":
            upstream = valor
    texto = raw.decode("utf-8", errors="replace").replace("\n", " ")
    if len(texto) > limite:
        texto = texto[:limite] + "…"
    anotar(f"{titulo} | HTTP {status} | upstream={upstream or '-'} | rid={rid or '-'} | {texto}")
    return status, upstream, rid


def main():
    anotar("== ruta desconocida ==")
    status, headers, raw = pedir("GET", GATEWAY + "/api/no-existe")
    resumir("GET /api/no-existe", status, headers, raw)

    anotar("== catalogo XML como Electron ==")
    status, headers, raw = pedir(
        "GET",
        GATEWAY + "/api/books/books",
        cabeceras={"Accept": "application/xml"},
    )
    resumir("GET /api/books/books", status, headers, raw, 120)
    anotar(f"xml_tiene_book={'<book>' in raw.decode('utf-8', errors='replace') or '<book ' in raw.decode('utf-8', errors='replace')}")

    anotar("== round robin de libros ==")
    puertos = []
    for i in range(6):
        status, headers, raw = pedir("GET", GATEWAY + "/api/books/books?format=json")
        _, upstream, _ = resumir(f"books #{i + 1}", status, headers, raw, 60)
        puertos.append(upstream)
    anotar("upstreams=" + json.dumps(puertos))

    anotar("== metrics oculto y GET /login bloqueado ==")
    status, headers, raw = pedir("GET", GATEWAY + "/api/books/metrics")
    resumir("GET /api/books/metrics", status, headers, raw)
    status, headers, raw = pedir("GET", GATEWAY + "/api/login/login")
    resumir("GET /api/login/login", status, headers, raw)

    anotar("== Authorization reenviado ==")
    status, headers, raw = pedir(
        "GET",
        GATEWAY + "/api/users/users",
        cabeceras={"Authorization": "Bearer token-invalido"},
    )
    resumir("GET /api/users/users Bearer", status, headers, raw)

    anotar("== SOAP como la app Java ==")
    sobre = """<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tns="http://udem.edu.mx/iac/library-classifier">
  <soap:Header/>
  <soap:Body>
    <tns:ObtenerConceptosPendientes>
      <tns:correo>mariana.solis@libreriaonline.mx</tns:correo>
      <tns:tipoCliente>desktop-java</tns:tipoCliente>
    </tns:ObtenerConceptosPendientes>
  </soap:Body>
</soap:Envelope>
"""
    req = urllib.request.Request(
        GATEWAY + "/api/books/soap",
        data=sobre.encode("utf-8"),
        headers={
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": "http://udem.edu.mx/iac/library-classifier/ObtenerConceptosPendientes",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            status, headers, raw = resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as exc:
        status, headers, raw = exc.code, dict(exc.headers), exc.read()
    except Exception as exc:
        status, headers, raw = 0, {}, str(exc).encode()
    resumir("POST /api/books/soap", status, headers, raw, 220)

    anotar("== salud del gateway ==")
    status, headers, raw = pedir("GET", GATEWAY + "/health")
    resumir("GET /health", status, headers, raw, 400)

    anotar("== limite de tasa en POST /api/login/login ==")
    codigos = []
    for _ in range(20):
        status, _, _ = pedir(
            "POST",
            GATEWAY + "/api/login/login?format=json",
            {"email": "nadie@example.com", "password": "no-se-registra"},
        )
        codigos.append(status)
    anotar("codigos_login=" + json.dumps(codigos))
    anotar(f"respuestas_429={codigos.count(429)}")

    log = Path("/tmp/libreria-nginx/access.log")
    if log.is_file():
        shutil.copy(log, OUT / "nginx-access.log")
        anotar(f"access_log_copiado={OUT / 'nginx-access.log'}")
    error = Path("/tmp/libreria-nginx/error.log")
    if error.is_file():
        shutil.copy(error, OUT / "nginx-error.log")

    destino = OUT / "prueba-proxy.txt"
    destino.write_text("\n".join(LINEAS) + "\n", encoding="utf-8")
    anotar(f"registro={destino}")


if __name__ == "__main__":
    main()
