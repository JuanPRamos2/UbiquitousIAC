#!/usr/bin/env bash
# Segunda instancia de Libros, solo para el round robin del proxy. Puerto 6001.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck disable=SC1091
source "$ROOT/scripts/ensure-python.sh"
ensure_libreria_python "$ROOT"
export SOAP_HOST="${SOAP_HOST:-127.0.0.1}"
export SOAP_PORT=6001
export SOAP_DEMO="${SOAP_DEMO:-1}"
export PYTHONPATH="$ROOT/services/shared:$ROOT/services/books${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT/services/books"
exec "$ROOT/.venv/bin/python" app.py
