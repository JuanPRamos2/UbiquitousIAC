#!/usr/bin/env bash
# Microservicios en 127.0.0.1 y Nginx en :8080.
# No toca un Postgres o Redis ajenos: si 5433 no es library_db, usa 5434 y 6380.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
# shellcheck disable=SC1091
source "$ROOT/scripts/ensure-python.sh"
ensure_libreria_python "$ROOT"
RUN_DIR="$ROOT/services/.run"
mkdir -p "$RUN_DIR"
PY="$ROOT/.venv/bin/python"

if [ "${1:-}" = "stop" ]; then
  if [ -f "$RUN_DIR/pids" ]; then
    while read -r pid; do
      kill "$pid" 2>/dev/null || true
    done <"$RUN_DIR/pids"
    rm -f "$RUN_DIR/pids"
  fi
  "$ROOT/scripts/run-proxy.sh" stop
  echo "Servicios del proxy detenidos. Postgres y Redis de esta sesión siguen en Docker."
  exit 0
fi

es_library() {
  docker run --rm --network host -e PGPASSWORD=666 postgres:16-bookworm \
    psql -h 127.0.0.1 -p "$1" -U library_user -d library_db -c 'select 1' >/dev/null 2>&1
}

if es_library 5433; then
  export DB_PORT=5433
  export REDIS_URL="${REDIS_URL:-redis://:libreria-redis@127.0.0.1:6379/0}"
  echo "Base de la librería en :5433"
else
  echo "El puerto 5433 no es library_db. Levantando Postgres :5434 y Redis :6380."
  docker compose -p libreria-sesion08 -f "$ROOT/infra/docker-compose.sesion08.yml" up -d
  for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
    if es_library 5434; then
      break
    fi
    sleep 2
  done
  es_library 5434
  export DB_PORT=5434
  export REDIS_URL="redis://:libreria-redis@127.0.0.1:6380/0"
fi

export DB_HOST=127.0.0.1
export DB_NAME=library_db
export DB_USER=library_user
export DB_PASSWORD=666
export HOST=127.0.0.1
export LOGIN_HOST=127.0.0.1
export SOAP_HOST=127.0.0.1
export SOAP_DEMO=1
export PYTHONPATH="$ROOT/services/shared${PYTHONPATH:+:$PYTHONPATH}"

: >"$RUN_DIR/pids"
lanzar() {
  local nombre="$1"
  local dir="$2"
  local puerto="$3"
  local codigo
  codigo="$(curl -s -m 1 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${puerto}/health" || true)"
  if [ "$codigo" != "000" ] && [ -n "$codigo" ]; then
    echo "$nombre ya escucha en :$puerto"
    return
  fi
  (
    cd "$ROOT/services/$dir"
    exec "$PY" app.py
  ) >"$RUN_DIR/$nombre.log" 2>&1 &
  echo $! >>"$RUN_DIR/pids"
  echo "$nombre arrancando (pid $!)"
}

lanzar login login 5000
lanzar books books 5001
lanzar users users 5002
lanzar autores authors 5003
lanzar pedidos pedidos 5004
lanzar pagos pagos 5005

if [ "$(curl -s -m 1 -o /dev/null -w '%{http_code}' "http://127.0.0.1:6001/health" || true)" = "000" ]; then
  SOAP_PORT=6001 "$ROOT/scripts/run-books-replica.sh" >"$RUN_DIR/books-6001.log" 2>&1 &
  echo $! >>"$RUN_DIR/pids"
  echo "books-6001 arrancando (pid $!)"
else
  echo "books ya escucha en :6001"
fi

for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
  listos=0
  for puerto in 5000 5001 5002 5003 5004 5005 6001; do
    if [ "$(curl -s -m 1 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${puerto}/health" || true)" != "000" ]; then
      listos=$((listos + 1))
    fi
  done
  if [ "$listos" = 7 ]; then
    break
  fi
  sleep 1
done

"$ROOT/scripts/run-proxy.sh"
echo
echo "Las apps hablan con http://127.0.0.1:8080/api/<servicio>"
echo "Para detener: ./scripts/run-con-proxy.sh stop"
