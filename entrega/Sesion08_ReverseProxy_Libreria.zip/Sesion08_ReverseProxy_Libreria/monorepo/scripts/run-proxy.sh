#!/usr/bin/env bash
# Levanta el agregador de /health y Nginx en el puerto 8080.
# Si no hay nginx en el sistema, usa la imagen nginx:1.27-alpine.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIR="$ROOT/infra/nginx"
RUN="/tmp/libreria-nginx"
PY="$ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  PY="$(command -v python3)"
fi

mkdir -p "$RUN/client_body" "$RUN/proxy" "$RUN/fastcgi" "$RUN/uwsgi" "$RUN/scgi"
chmod 777 "$RUN" "$RUN"/*/ 2>/dev/null || true

detener() {
  if [ -f "$RUN/nginx.pid" ]; then
    kill "$(cat "$RUN/nginx.pid")" 2>/dev/null || true
    rm -f "$RUN/nginx.pid"
  fi
  docker rm -f libreria-nginx >/dev/null 2>&1 || true
  if [ -f "$RUN/salud.pid" ]; then
    kill "$(cat "$RUN/salud.pid")" 2>/dev/null || true
    rm -f "$RUN/salud.pid"
  fi
}

if [ "${1:-}" = "stop" ]; then
  detener
  echo "Proxy detenido."
  exit 0
fi

salud="$(curl -s -m 1 -o /dev/null -w '%{http_code}' "http://127.0.0.1:8090/health" || true)"
if [ "$salud" != "200" ] && [ "$salud" != "503" ]; then
  nohup "$PY" "$DIR/salud.py" >"$RUN/salud.log" 2>&1 &
  echo $! >"$RUN/salud.pid"
fi

if command -v nginx >/dev/null 2>&1; then
  docker rm -f libreria-nginx >/dev/null 2>&1 || true
  if [ -f "$RUN/nginx.pid" ] && kill -0 "$(cat "$RUN/nginx.pid")" 2>/dev/null; then
    kill "$(cat "$RUN/nginx.pid")" 2>/dev/null || true
    sleep 0.2
  fi
  nginx -c "$DIR/library.conf"
  echo "Nginx del sistema en http://127.0.0.1:8080"
else
  docker rm -f libreria-nginx >/dev/null 2>&1 || true
  docker run -d --name libreria-nginx --network host \
    -v "$DIR/library.conf:/etc/nginx/nginx.conf:ro" \
    -v "$DIR/proxy_params.conf:/etc/nginx/proxy_params.conf:ro" \
    -v "$RUN:$RUN" \
    nginx:1.27-alpine >/dev/null
  echo "Nginx (contenedor nginx:1.27-alpine) en http://127.0.0.1:8080"
fi

for _ in 1 2 3 4 5 6 7 8 9 10; do
  codigo="$(curl -s -m 2 -o /dev/null -w '%{http_code}' "http://127.0.0.1:8080/health" || true)"
  if [ "$codigo" = "200" ] || [ "$codigo" = "503" ]; then
    echo "Proxy respondiendo en :8080 (health HTTP $codigo)"
    exit 0
  fi
  sleep 0.4
done

echo "Nginx no respondió. Revisa $RUN/error.log y, si usaste Docker, docker logs libreria-nginx" >&2
exit 1
