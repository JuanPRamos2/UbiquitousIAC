"""Sirve el Flask SOAP/JSON en el puerto 5001."""
import sys
from pathlib import Path

from werkzeug.serving import make_server

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "services" / "books"))
from app import app  # noqa: E402
from config import settings  # noqa: E402


def _serve():
    make_server(settings.SOAP_HOST, settings.SOAP_PORT, app, threaded=True).serve_forever()


if __name__ == "__main__":
    print(f"Flask SOAP/JSON en http://{settings.SOAP_HOST}:{settings.SOAP_PORT}")
    _serve()
