import logging
import re
from pathlib import Path

from flask import Flask, Response, request, send_from_directory

import bootstrap_shared  # noqa: F401
from books_api import register_books_routes
from config import settings
from libreria_platform.web import apply_cors
from soap.envelope import body_operation, parse_envelope
from soap.faults import SoapFault, client_fault, server_fault
from soap.service import handle
from xml_format import respond, wants_json

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("library_soap")

app = Flask(__name__)
try:
    apply_cors(app)
except Exception:
    pass

SOAP_DIR = Path(__file__).resolve().parent
UI_DIR = SOAP_DIR / "static" / "ui"
COVERS_DIR = SOAP_DIR / "static" / "covers"
WSDL_TEXT = Path(settings.WSDL_PATH).read_text(encoding="utf-8")


def _wsdl_for_request():
    location = request.url_root.rstrip("/") + "/soap"
    return WSDL_TEXT.replace("http://localhost:5000/soap", location).replace(
        "http://localhost:5001/soap", location
    )


def _probar_html():
    html = (UI_DIR / "probar.html").read_text(encoding="utf-8")
    if "<body" in html and "data-soap-endpoint" not in html:
        html = html.replace("<body>", '<body data-soap-endpoint="/soap">')
    return html


def _service_descriptor():
    return {
        "service": "LibraryClassifier",
        "ports": [5001],
        "wsdl": "/soap?wsdl",
        "endpoint": "/soap",
        "demo": settings.SOAP_DEMO,
        "defaultFormat": "xml",
        "jsonParameter": "format=json",
        "jwt": {
            "scheme": "Bearer",
            "issuedBy": "login",
            "public": ["GET /books", "GET /books/{isbn}"],
            "protected": ["POST /books", "PUT /books/{isbn}", "PATCH /books/{isbn}", "DELETE /books/{isbn}"],
        },
        "library": "http://127.0.0.1:3000/library",
        "endpoints": [
            {"path": "/books", "methods": "GET", "description": "Catálogo XML/JSON (público)"},
            {"path": "/books/9780451524935", "methods": "GET", "description": "1984 (público)"},
            {
                "path": "/books",
                "methods": "POST, PUT, PATCH, DELETE",
                "description": "Escritura con Authorization: Bearer JWT del login",
            },
            {"path": "/cloud-concepts", "methods": "GET", "description": "IaaS PaaS SaaS FaaS"},
            {"path": "/books-images", "methods": "GET", "description": "Libros e imágenes"},
            {"path": "/soap", "methods": "GET, POST", "description": "WSDL y SOAP"},
        ],
    }


@app.get("/")
def index():
    if wants_json() or (request.args.get("format") or "").strip().lower() == "xml":
        return respond(_service_descriptor(), root_tag="service")
    return Response(_probar_html(), mimetype="text/html; charset=utf-8")


@app.get("/probar.html")
def probar():
    return Response(_probar_html(), mimetype="text/html; charset=utf-8")


@app.get("/ui/<path:filename>")
def ui_file(filename):
    return send_from_directory(UI_DIR, filename)


@app.get("/covers/<path:filename>")
def cover_file(filename):
    match = re.search(r"(\d{10,13})", filename)
    if match:
        svg_name = f"{match.group(1)}.svg"
        if (COVERS_DIR / svg_name).exists():
            return send_from_directory(COVERS_DIR, svg_name)
    return send_from_directory(COVERS_DIR, filename)


@app.get("/soap")
@app.get("/wsdl")
def wsdl():
    if wants_json():
        return respond(
            {
                "format": "json",
                "wsdl": "/soap?wsdl",
                "location": request.url_root.rstrip("/") + "/soap",
                "ports": [5001],
                "operations": [
                    "ObtenerConceptosPendientes",
                    "RegistrarClasificacion",
                    "ObtenerProgresoUsuario",
                    "ObtenerEstadisticasPorModelo",
                ],
            },
            root_tag="soapInfo",
        )
    return Response(_wsdl_for_request(), mimetype="text/xml; charset=utf-8")


@app.post("/demo/reset")
def demo_reset():
    if not settings.SOAP_DEMO:
        return respond({"error": "Not found"}, root_tag="error", status=404)
    from db.demo_store import reset

    reset()
    return respond({"ok": True}, root_tag="result")


@app.post("/soap")
def soap_endpoint():
    raw = request.get_data()
    if not raw:
        fault = client_fault("El cuerpo HTTP está vacío")
        return Response(fault.to_xml(), status=fault.http_status, mimetype="text/xml; charset=utf-8")
    try:
        _root, header, body = parse_envelope(raw)
        payload = body_operation(body)
        if payload is None:
            raise client_fault("El Body SOAP no contiene una operación")
        xml = handle(header, payload)
        return Response(xml, status=200, mimetype="text/xml; charset=utf-8")
    except SoapFault as fault:
        return Response(fault.to_xml(), status=fault.http_status, mimetype="text/xml; charset=utf-8")
    except ValueError as exc:
        fault = client_fault(str(exc))
        return Response(fault.to_xml(), status=fault.http_status, mimetype="text/xml; charset=utf-8")
    except Exception:
        logger.exception("Error no controlado en el endpoint SOAP")
        fault = server_fault()
        return Response(fault.to_xml(), status=fault.http_status, mimetype="text/xml; charset=utf-8")


register_books_routes(app)


if __name__ == "__main__":
    app.run(host=settings.SOAP_HOST, port=settings.SOAP_PORT, debug=False)
