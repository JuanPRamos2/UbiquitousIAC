"""
Servicio de aplicación de la Plataforma de Bienestar Laboral.

Alcance de este archivo en el primer parcial: probar que la plataforma
corre de forma idéntica en los tres ambientes exigidos, contra la base
de datos real y contra Redis. Los módulos de negocio M01 a M12 se
construyen sobre esta base en la siguiente etapa.
"""
import logging
import time

import psycopg2
import redis
from flask import Flask, g, jsonify, request
from psycopg2 import pool

from .config import Config

_pool = None
_redis = None


def _obtener_pool():
    global _pool
    if _pool is None:
        _pool = pool.ThreadedConnectionPool(
            Config.PG_POOL_MIN, Config.PG_POOL_MAX, Config.dsn()
        )
    return _pool


def _obtener_redis():
    global _redis
    if _redis is None:
        _redis = redis.Redis(
            host=Config.REDIS_HOST,
            port=Config.REDIS_PUERTO,
            socket_connect_timeout=2,
            decode_responses=True,
        )
    return _redis


def crear_app() -> Flask:
    app = Flask(__name__)
    logging.basicConfig(
        level=getattr(logging, Config.NIVEL_BITACORA, logging.INFO),
        format="%(asctime)s %(levelname)s [" + Config.AMBIENTE + "] %(message)s",
    )

    @app.before_request
    def _marcar_inicio():
        g.inicio = time.perf_counter()

    @app.after_request
    def _registrar(respuesta):
        ms = (time.perf_counter() - getattr(g, "inicio", time.perf_counter())) * 1000
        app.logger.info("%s %s -> %s en %.1f ms",
                        request.method, request.path, respuesta.status_code, ms)
        return respuesta

    # ------------------------------------------------------------------
    # Sondas de salud. Kubernetes, Cloud Run y el balanceador de GCP
    # esperan exactamente esta separación: "vivo" no implica "listo".
    # ------------------------------------------------------------------
    @app.get("/salud")
    def salud():
        """El proceso responde. No dice nada sobre sus dependencias."""
        return jsonify(estado="vivo", ambiente=Config.AMBIENTE)

    @app.get("/listo")
    def listo():
        """Verifica que las dependencias contesten antes de recibir tráfico."""
        detalle = {}
        ok = True

        t = time.perf_counter()
        try:
            cn = _obtener_pool().getconn()
            try:
                with cn.cursor() as cur:
                    cur.execute("SELECT 1")
                    cur.fetchone()
            finally:
                _obtener_pool().putconn(cn)
            detalle["postgresql"] = {
                "ok": True, "ms": round((time.perf_counter() - t) * 1000, 1)
            }
        except Exception as e:
            ok = False
            detalle["postgresql"] = {"ok": False, "error": _mensaje(e)}

        t = time.perf_counter()
        try:
            _obtener_redis().ping()
            detalle["redis"] = {
                "ok": True, "ms": round((time.perf_counter() - t) * 1000, 1)
            }
        except Exception as e:
            ok = False
            detalle["redis"] = {"ok": False, "error": _mensaje(e)}

        return jsonify(estado="listo" if ok else "no_listo",
                       ambiente=Config.AMBIENTE,
                       dependencias=detalle), (200 if ok else 503)

    # ------------------------------------------------------------------
    # Endpoint de dominio. Existe para demostrar que la aplicación puede
    # invocar el mecanismo de privacidad diferencial de la base de datos.
    # ------------------------------------------------------------------
    @app.get("/agregado/<campania>/<unidad>")
    def agregado(campania, unidad):
        actor = request.headers.get("X-Actor-Id")
        if not actor:
            return jsonify(error="Falta el encabezado X-Actor-Id"), 400

        clave = f"agregado:{campania}:{unidad}"
        rc = _obtener_redis()
        try:
            guardado = rc.get(clave)
            if guardado:
                return app.response_class(guardado, mimetype="application/json",
                                          headers={"X-Cache": "HIT"})
        except Exception:
            # Redis caído no puede tumbar la consulta: degrada a la base.
            app.logger.warning("Redis no disponible; se consulta sin caché")

        cn = _obtener_pool().getconn()
        try:
            with cn.cursor() as cur:
                cur.execute(
                    "SELECT estado, n, valor_protegido, epsilon, escala_ruido, mensaje "
                    "FROM agregado.fn_calcular_agregado_protegido(%s, %s, NULL, %s)",
                    (campania, unidad, actor),
                )
                fila = cur.fetchone()
            cn.commit()
        except Exception as e:
            cn.rollback()
            return jsonify(error=_mensaje(e)), 500
        finally:
            _obtener_pool().putconn(cn)

        if fila is None:
            return jsonify(error="Sin resultado"), 404

        cuerpo = {
            "estado": fila[0],
            "n": fila[1],
            "valor_protegido": float(fila[2]) if fila[2] is not None else None,
            "epsilon": float(fila[3]) if fila[3] is not None else None,
            "escala_ruido": float(fila[4]) if fila[4] is not None else None,
            "mensaje": fila[5],
        }
        # Solo se cachea lo que sí se publicó. Un resultado suprimido no se
        # guarda, para que un cambio de participación se refleje enseguida.
        if fila[0] == "PUBLICADO":
            try:
                rc.setex(clave, 900, jsonify(cuerpo).get_data(as_text=True))
            except Exception:
                pass
        return jsonify(cuerpo), (200 if fila[0] == "PUBLICADO" else 409)

    return app


def _mensaje(e: Exception) -> str:
    """Fuera de developer no se devuelve el detalle del error al cliente."""
    return str(e) if Config.MOSTRAR_ERRORES else "Error interno del servicio"
