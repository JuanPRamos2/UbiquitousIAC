"""
Configuración por ambiente.

Regla del proyecto: la aplicación NO conoce el ambiente en el que corre.
Solo lee variables de entorno. El ambiente se decide en infraestructura,
no en el código. Esto es lo que permite que la misma imagen de contenedor
recorra developer, staging y production sin recompilarse.
"""
import os


def _obligatoria(nombre: str) -> str:
    valor = os.environ.get(nombre)
    if not valor:
        raise RuntimeError(
            f"Falta la variable de entorno {nombre}. "
            f"Revisa infra/ambientes/<ambiente>.env"
        )
    return valor


class Config:
    # Identidad del ambiente: solo se usa para bitácora y para la respuesta
    # de /salud. Nunca para cambiar comportamiento del negocio.
    AMBIENTE = os.environ.get("APP_AMBIENTE", "developer")

    # Base de datos
    PG_HOST = os.environ.get("PG_HOST", "datos")
    PG_PUERTO = int(os.environ.get("PG_PUERTO", "5432"))
    PG_BASE = os.environ.get("PG_BASE", "bienestar")
    PG_USUARIO = os.environ.get("PG_USUARIO", "bienestar_app")
    PG_CLAVE = _obligatoria("PG_CLAVE")
    PG_POOL_MIN = int(os.environ.get("PG_POOL_MIN", "1"))
    PG_POOL_MAX = int(os.environ.get("PG_POOL_MAX", "8"))

    # Caché y sesiones
    REDIS_HOST = os.environ.get("REDIS_HOST", "cache")
    REDIS_PUERTO = int(os.environ.get("REDIS_PUERTO", "6379"))

    # Operación
    NIVEL_BITACORA = os.environ.get("NIVEL_BITACORA", "INFO")
    # En developer se permite ver el detalle del error; fuera de ahí no,
    # porque un rastro de excepción puede filtrar estructura de la base.
    MOSTRAR_ERRORES = os.environ.get("MOSTRAR_ERRORES", "false").lower() == "true"

    @classmethod
    def dsn(cls) -> str:
        return (
            f"host={cls.PG_HOST} port={cls.PG_PUERTO} dbname={cls.PG_BASE} "
            f"user={cls.PG_USUARIO} password={cls.PG_CLAVE} "
            f"application_name=bienestar-api-{cls.AMBIENTE}"
        )
